APA 7th Edition Student Paper Template (LaTeX)
==============================================
Created by Parisa Rostami
https://github.com/ParisaRostaami/APA7-LaTeX-Template
License: CC BY-NC 4.0 (see LICENSE). Your paper is yours.

Files
  main.tex         Your paper. Edit the TITLE PAGE block, then write.
  references.bib   Your sources (BibTeX format).
  figures/         Put your images here (one sample figure included).
  LICENSE          License for the template.

Easiest way: Overleaf (free, nothing to install)
  1. Go to overleaf.com and sign in.
  2. New Project -> Upload Project -> select this .zip file.
  3. Click Recompile. That's it.

Compiling on your own computer
  Needs a TeX distribution (TeX Live or MiKTeX) with the apa7 and
  biblatex-apa packages, and Biber. Then run:
      latexmk -pdf main.tex
  or: pdflatex main -> biber main -> pdflatex main -> pdflatex main

Citing
  \parencite{key}          (Author, 2020)
  \textcite{key}           Author (2020)
  \parencite[p.~12]{key}   (Author, 2020, p. 12)
  Only sources you cite appear in the References list.

Common problems
  - References list is empty or citations show as bold keys:
    Biber did not run. On Overleaf, check Menu -> Compiler is pdfLaTeX
    and recompile. Locally, run biber (see above).
  - Capital letters disappear in a reference title (e.g., "Bert"):
    put braces around them in references.bib:  {BERT}
  - "Undefined control sequence": a typo in a LaTeX command, or a
    special character. Write & as \&, % as \%, _ as \_, $ as \$.

The template already handles: 1-inch margins, double spacing, Times
New Roman 12 pt, 0.5-inch indents, page numbers, the student title
page, heading levels 1-5, table/figure labels, and the reference list.

A full step-by-step guide (PDF and Word) is in the GitHub repository.
